__version__ = '2.1.0rc2'
__git_version__ = ''
