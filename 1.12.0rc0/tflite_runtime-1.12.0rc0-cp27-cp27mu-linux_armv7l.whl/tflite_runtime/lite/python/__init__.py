# Python module for TensorFlow Lite
