__version__ = '2.1.0rc0'
__git_version__ = '0.6.0-71493-gc6daad319d'
